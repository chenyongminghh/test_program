#!/bin/bash

if [ $# -ne 4 ]; then
    echo "Usage: $0 mc_port sn_code chip_id soc_voltage"
    exit 1
fi

test_name=$0
mc_port=$1
sn_code=$2
chip_id=$3
soc_voltage=$4
d2d_bin_path="ant_d2d_bin"

echo "test_name     : $test_name"
echo "mc_port       : $mc_port"
echo "sn_code       : $sn_code"
echo "chip_id       : $chip_id"
echo "soc_voltage   : $soc_voltage"

#d2d train
echo "Start d2d training"
cd ${d2d_bin_path}
sudo ./MLU370_D2D_HOST_init_v0052_0004 -i $mc_port -f 0  || exit 1
cd ..
    
#add d2d para image header
echo "Start d2d image header creating"
./creat_d2d_para.sh ${sn_code} ${chip_id} 0052 ${soc_voltage}  || exit 1

#load d2d para
echo "Start d2d image flashing"
sudo ./MLU370_norflash_tool_v1.1 -i $mc_port -f 1  || exit 1

#load ddr and isse para
echo "Start ddr and isse image flashing"
sudo ./MLU370_norflash_tool_v1.1 -i $mc_port -f 0  || exit 1
