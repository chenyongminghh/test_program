#!/bin/bash

set -e
set -x

#${1} sn_code
#${2} chip_id
#${3} d2d_version
#${4} d2d_voltage

sn_code=${1}_${2}
d2d_version=${3}
d2d_voltage=${4}
d2d_bin_path="ant_d2d_bin"

#d2d para
cp ${d2d_bin_path}/d2d_bin/${sn_code}_d2d_paras.bin ${d2d_bin_path}/m0_d2d_para/  || exit 1

cp ${d2d_bin_path}/m0_d2d_para/${sn_code}_d2d_paras.bin imageheader  || exit 1
ln -sf ../${d2d_bin_path}/m0_d2d_para/target.cfg imageheader/target.cfg || exit 1

./imageheader/imageheader.py imageheader/${sn_code}_d2d_paras_full.bin imageheader/${sn_code}_d2d_paras.bin imageheader/target.cfg ${d2d_version} ${d2d_voltage} || exit 1
rm imageheader/${sn_code}_d2d_paras.bin || exit 1
mv imageheader/${sn_code}_d2d_paras_full.bin ${d2d_bin_path}/m0_d2d_para || exit 1
