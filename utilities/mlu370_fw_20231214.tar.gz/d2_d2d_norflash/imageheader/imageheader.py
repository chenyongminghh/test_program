#!/usr/bin/python3


# image header structure is :
#       FIELD NAME                                        SIZE (bytes)
#       ----------------------------------------------------------------------
#       mMagicNum                                         4
#       mVersion                                          4
#       mPayloadHash                                      32
#       mImgSize                                          4
#       mFileType                                         4
#       mBlockId                                          4
#       mPayloadCrc                                       4
#       d2dParaDate                                       4
#       d2dParaVersion                                    4
#       d2dParaVoltage                                    4
#       mPayloadCrcWhole                                  4
#       reserved                                          (512-72)
       


import sys
import os
import hashlib
import struct
from enum import Enum
import crc16
import crc32
import configparser
import time


MAGICNUM = 0x696d6864                   ## magic number = imhd(image header)
HDRLIMIT = 512                          ## the max size of image header
HDRSUFFIX = "-header"                   ## suffix of output image file name
PAYLOADHASH_LEN = 32
CRC16_LEN = 2
WORD_LEN = 4
CRC_DATA_LEN = 1024                     ## only cover the last 1kb data
CRC32_LEN = 4
IMAGE_HEADER_SECTION = "IMG-HEADER-CFG"


class HdrImage:
    def __init__(self, _imgFileName, _filetype, _version):
        fBaseName = os.path.basename(_imgFileName)

        self.imgFileName = _imgFileName
        self.mMagicNum = MAGICNUM
        self.mVersion = _version
        self.mFileType = _filetype
        self.mBlockId = 0
        try:
            imgFd = open(_imgFileName, 'rb')
            self.payload = imgFd.read()
            imgFd.close()
        except IOError as e:
            print(e.strerror)
            sys.exit(e.errno)

        fileInfo = os.stat(self.imgFileName)
        self.originSize = fileInfo.st_size

        if self.originSize > HDRLIMIT:
            imageMagicNum = struct.unpack("<I", self.payload[0:4])[0]
            imageVersion = struct.unpack("<I", self.payload[4:8])[0]
            if imageVersion == _version and imageMagicNum == MAGICNUM:
                print("this image has already have a header")
                sys.exit(0)

    def serialize2File(self, hashtype, crctype, paddingflag, outfile, version, voltage,crcwholeflag):
        if paddingflag == 1:
            self.mImgSize = (self.originSize + 15) // 16 * 16
            self.payload += bytes('\0' * (self.mImgSize - self.originSize), 'utf-8')
        else:
            self.mImgSize = self.originSize
            self.payload = self.payload

        if hashtype == 1:
            h = hashlib.sha256(self.payload)
            self.mPayloadHash = h.digest()
        else:
            self.mPayloadHash = bytes('\0' * PAYLOADHASH_LEN, 'utf-8')

        if crctype == 1:
            if len(self.payload) > CRC_DATA_LEN:
                self.mPayloadCrc = crc16.crc16xmodem(self.payload[-CRC_DATA_LEN:]).to_bytes(2, byteorder="little")
            else:
                self.mPayloadCrc = crc16.crc16xmodem(self.payload).to_bytes(2, byteorder="little")
            self.mPayloadCrc += bytes('\0' * (WORD_LEN - CRC16_LEN), 'utf-8')
        elif crctype == 2:
            self.mPayloadCrc = crc32.crc32(self.payload).to_bytes(4, byteorder="little")
        else:
            self.mPayloadCrc = bytes('\0' * WORD_LEN, 'utf-8')

        if crcwholeflag == 1:
            self.mPayloadCrcWhole = crc16.crc16xmodem(self.payload).to_bytes(2, byteorder="little")
        else:
            self.mPayloadCrcWhole = bytes('\0' * WORD_LEN, 'utf-8')


        year = time.strftime("%Y%m%d",time.localtime())
        print("year : ",int(year,16))
    
        d2d_para_date = int(year,16)

        magicNumPacked = struct.pack("<I", self.mMagicNum)
        versionPacked = struct.pack("<I", self.mVersion)
        imgSizePacked = struct.pack("<I", self.mImgSize)
        fileTypePacked = struct.pack("<I", self.mFileType)
        blockIDPacked = struct.pack("<I", self.mBlockId)
        d2dParaDate = struct.pack("<I", d2d_para_date)
        d2dParaVersion = struct.pack("<I",version)
        d2dParaVoltage = struct.pack("<I",voltage)

        header = magicNumPacked + versionPacked + self.mPayloadHash + \
                imgSizePacked + fileTypePacked + blockIDPacked + self.mPayloadCrc + d2dParaDate + d2dParaVersion + d2dParaVoltage + self.mPayloadCrcWhole

        paddingSize = HDRLIMIT - len(magicNumPacked) - len(versionPacked) - \
                len(self.mPayloadHash) - len(imgSizePacked) - \
                len(fileTypePacked) - len(blockIDPacked) - len(self.mPayloadCrc) - len(d2dParaDate) - len(d2dParaVersion) - len(d2dParaVoltage) -len(self.mPayloadCrcWhole)

        img = header + bytes('\0' * (paddingSize), 'utf-8') + self.payload 

        fileNameList = os.path.split(self.imgFileName)
        baseNameList = fileNameList[1].split(".")
        baseNameList[0] += HDRSUFFIX
        dstBaseName = ".".join(baseNameList)
        #dstFileName = os.path.join(fileNameList[0], dstBaseName)

        try:
            #FileObj = open(dstFileName, "wb")
            FileObj = open(outfile, "wb")
            FileObj.write(img)
            FileObj.close()
        except IOError as Error7:
            (errno, strerror) = Error7.args
            printf(strerror)
            sys.exit(errno)

def parse_section (config, data_dict):
    if not config.has_section(IMAGE_HEADER_SECTION):
        print("section " + IMAGE_HEADER_SECTION + " wasn't found in cfg file\n")
        sys.exit(1)

    data_dict['image_header_version'] = config.get(IMAGE_HEADER_SECTION, 'image-header-version')
    data_dict['image_file_type'] = config.get(IMAGE_HEADER_SECTION, 'image-file-type')
    data_dict['image_hash_type'] = config.get(IMAGE_HEADER_SECTION, 'image-hash-type')
    data_dict['image_crc_type'] = config.get(IMAGE_HEADER_SECTION, 'image-crc-type')
    data_dict['image_padding_flag'] = config.get(IMAGE_HEADER_SECTION, 'image-padding-flag')
    data_dict['image_crc_whole_flag'] = config.get(IMAGE_HEADER_SECTION, 'image-crc-whole-flag')

def main():
    len_arg =  len(sys.argv)
    if len_arg != 6:
        print("Invalid. Usage: ");
        print("$./imageheader.py <outfile> <infile> <configfile>");
        print("-outfile                -- output file name")
        print("-infile                 --the image to be inserted with sys_img_header");
        print("-configfile             --config file");
        sys.exit(1)

    outfile = sys.argv[1]
    filename = sys.argv[2]
    configfile = sys.argv[3]

    d2d_version = int(sys.argv[4],16)
    d2d_voltage = int(sys.argv[5],16)

    print(time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()))



    config = configparser.ConfigParser()
    config.read(configfile)           
                                        
    data_dict = {}                      
    parse_section(config, data_dict)    

    filetype = int(data_dict['image_file_type'], 10)
    version = int(data_dict['image_header_version'], 16)

    if data_dict['image_padding_flag'] == '0':
        paddingflag = False
    else:
        paddingflag = True

    hashtype = int(data_dict['image_hash_type'], 10)
    crctype = int(data_dict['image_crc_type'], 10)
    crcwholeflag = int(data_dict['image_crc_whole_flag'],10)

    ## block ID use 'master' as default
    img = HdrImage(filename, filetype, version)
    img.serialize2File(hashtype, crctype, paddingflag, outfile,d2d_version,d2d_voltage,crcwholeflag)

    sys.exit(0)

if __name__ == "__main__":

    if sys.version_info<(3,0,0):
        print("You need python 3.0 or later to run this script")
        exit(1)

    main()




                
