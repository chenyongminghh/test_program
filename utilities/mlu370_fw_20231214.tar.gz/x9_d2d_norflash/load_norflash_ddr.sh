#!/bin/bash

if [ $# -ne 4 ]; then
    echo "Usage: $0 mc_port sn_code chip_id soc_voltage"
    exit 1
fi

test_name=$0
mc_port=$1
sn_code=$2
chip_id=$3
soc_voltage=$4
d2d_bin_path="ant_d2d_bin"

echo "test_name     : $test_name"
echo "mc_port       : $mc_port"
echo "sn_code       : $sn_code"
echo "chip_id       : $chip_id"
echo "soc_voltage   : $soc_voltage"

#load ddr and isse para
echo "Start ddr and isse image flashing"
sudo ./MLU370_norflash_tool_v1.2 -i $mc_port -f 2  || exit 1