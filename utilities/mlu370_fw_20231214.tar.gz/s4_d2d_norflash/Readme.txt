
Step1:
cd ant_d2d_bin
sudo ./MLU370_D2D_HOST_init_v48 -i mcPort -f 0
cd ..


Step2:
#add d2d para image header
./creat_d2d_para.sh ${sn_code} 0048 75


Step3:
#load d2d para
sudo ./MLU370_norflash_tool_v0.3 -i mcPort -f 1